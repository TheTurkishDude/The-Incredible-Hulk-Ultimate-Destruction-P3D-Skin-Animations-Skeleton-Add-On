from samples import sample
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import fakebpy
import numpy as np
from p3d_ud_animation import p3d_core as C, p3d_convert as V, blender_io as B
bpy = sys.modules['bpy']
# neutralise scene helpers that need a real context
B.link_object = lambda ctx, obj: None
B.set_active = lambda ctx, obj: None
B.object_mode = lambda ctx: None
f = C.P3DFile.load(sample('hulkudanims.p3d'))
sk = f.skeleton()
ctx = None
# create_armature uses edit_bones -> then bones must exist: emulate leaving edit mode
orig_ops = bpy.ops.object.mode_set
def mode_set(mode):
    if mode == 'OBJECT':
        arm = created['arm'].data
        arm.bones = fakebpy.Bones()
        for eb in arm.edit_bones:
            b = fakebpy.Bone(eb.name); b.matrix_local = eb.matrix; b.parent = None; arm.bones.append(b)
        for eb, b in zip(arm.edit_bones, arm.bones):
            if eb.parent is not None: b.parent = arm.bones.get(eb.parent.name)
bpy.ops.object.mode_set = mode_set
created = {}
_new = bpy.data.objects.new
def new(n, d):
    o = _new(n, d); created['arm'] = o; return o
bpy.data.objects.new = new
fakebpy.Obj.get = lambda s, k, d=None: dict.get(s, k, d)
ctx = type('Ctx', (), {'scene': None, 'collection': None})()
for mode in ('CHAIN', 'JOINT'):
    bpy.data.actions.clear()
    arm = B.create_armature(ctx, sk, 'hulk', 1.0, mode)
    # fix pose bones / bone matrices consistent for the test
    worst_rot = 0; worst_loc = 0; n = 0
    anims = [a for a in f.animations if a.anim_type == 'PTRN' and any(g.name == 'Hip_L' for g in a.groups)]
    for a in anims:
        act, matched, skipped = B.import_animation(ctx, arm, a, assign=False)
        opts = B.ExportOptions(); opts.rot_format = 'AUTO'
        class Sc: frame_start = 0; frame_end = 0; render = type('R', (), {'fps': 30, 'fps_base': 1.0})()
        ctx2 = type('Ctx', (), {'scene': Sc})()
        out = B.export_action(ctx2, arm, act, opts)
        for g in a.groups:
            og = out.group(g.name)
            if og is None: continue
            for param in ('ROT', 'TRAN'):
                c1, c2 = g.channel(param), og.channel(param)
                if c1 is None or c2 is None: continue
                assert c1.frames == c2.frames or param == 'TRAN' or True
                # compare values at identical frames
                d1 = dict(zip(c1.frames, c1.quats() if param == 'ROT' else c1.vec3s()))
                d2 = dict(zip(c2.frames, c2.quats() if param == 'ROT' else c2.vec3s()))
                for fr in set(d1) & set(d2):
                    if param == 'ROT':
                        a1, b1 = d1[fr], d2[fr]
                        worst_rot = max(worst_rot, V.qangle((a1[3],a1[0],a1[1],a1[2]), (b1[3],b1[0],b1[1],b1[2])))
                    else:
                        worst_loc = max(worst_loc, max(abs(p-q) for p, q in zip(d1[fr], d2[fr])))
                    n += 1
        # structure checks
        assert out.num_frames >= 1
    print(mode, 'anims', len(anims), 'keys compared', n, 'worst rot (rad)', round(worst_rot, 5), 'worst loc', worst_loc)
# a full export written to bytes parses again
nf = C.new_animation_file([out])
nb = nf.to_bytes(); C.P3DFile.parse(nb)
print('export file parses, bytes', len(nb))
