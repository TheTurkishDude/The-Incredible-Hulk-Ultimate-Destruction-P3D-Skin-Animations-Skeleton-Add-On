from samples import sample
import sys, os, types, json
sys.path.insert(0, os.path.dirname(__file__))
import fakebpy
from p3d_ud_animation import p3d_core as C, blender_io as B
bpy = sys.modules['bpy']
class L(list):
    def foreach_set(s, name, flat): s.flat = list(flat)
class Mesh:
    def __init__(s, n): s.name = n; s.materials = []; s.vertices = []; s.polygons = []; s.loops = []; s.uv_layers = types.SimpleNamespace(new=lambda name: types.SimpleNamespace(data=_FS()))
    def from_pydata(s, v, e, f): s.vertices = list(v); s.polygons = _FS(f); s.loops = list(range(3 * len(f))); s.faces = f
    def update(s): pass
class _FS(list):
    def foreach_set(s, name, flat): s.last = (name, len(flat))
class VG:
    def __init__(s, n): s.name = n; s.w = {}
    def add(s, idx, w, mode): s.w[idx[0]] = w
class Obj2(dict):
    def __init__(s, n, d): super().__init__(); s.name = n; s.data = d; s.parent = None
    vertex_groups = None
bpy.data.meshes = types.SimpleNamespace(new=lambda n: Mesh(n))
bpy.data.materials = types.SimpleNamespace(get=lambda n: None, new=lambda n: types.SimpleNamespace(name=n))
def new_obj(n, d):
    o = Obj2(n, d); o.vertex_groups = types.SimpleNamespace(groups=[], new=None)
    def vgnew(name): v = VG(name); o.vertex_groups.groups.append(v); return v
    o.vertex_groups.new = vgnew
    o.modifiers = types.SimpleNamespace(new=lambda n, t: types.SimpleNamespace(object=None))
    return o
bpy.data.objects.new = new_obj
B.link_object = lambda c, o: None
xb = C.P3DFile.load(sample('hulkudanims.p3d'))
names = [j.name for j in xb.skeleton().joints]
ps = C.P3DFile.load(sample('global_hulk.p3d'))
skin = ps.polyskin()
obj = B.create_skin_mesh(None, skin, None, names, 1.0, True, False)
m = obj.data
print('verts', len(m.vertices), 'faces', len(m.faces), 'materials', [x.name for x in m.materials])
vg = {v.name: v for v in obj.vertex_groups.groups}
print('vertex groups', len(vg), sorted(vg)[:6], 'weighted verts', sum(len(v.w) for v in vg.values()))
assert set(vg) <= set(names)
tot = {}
for v in vg.values():
    for i, w in v.w.items(): tot[i] = tot.get(i, 0) + w
print('every vertex fully weighted:', all(abs(w - 1) < 1e-4 for w in tot.values()), len(tot), 'of', len(m.vertices))
