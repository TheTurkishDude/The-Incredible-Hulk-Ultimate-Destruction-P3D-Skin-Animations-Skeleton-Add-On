from samples import sample
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import fakebpy
from p3d_ud_animation import p3d_core as C, p3d_convert as V, blender_io as B
bpy = sys.modules['bpy']
B.link_object = lambda c, o: None; B.set_active = lambda c, o: None; B.object_mode = lambda c: None
f = C.P3DFile.load(sample('hulkudanims.p3d')); sk = f.skeleton()
created = {}
_new = bpy.data.objects.new
bpy.data.objects.new = lambda n, d: created.setdefault('arm', _new(n, d))
fakebpy.Obj.get = lambda s, k, d=None: dict.get(s, k, d)
def mode_set(mode):
    if mode == 'OBJECT':
        arm = created['arm'].data
        old = {b.name: b for b in arm.bones}
        arm.bones = fakebpy.Bones()
        for eb in arm.edit_bones:
            b = old.get(eb.name) or fakebpy.Bone(eb.name); b.matrix_local = eb.matrix if hasattr(eb, '_m') else fakebpy.Matrix(__import__('numpy').eye(4))
            b.parent = None; arm.bones.append(b)
        for eb, b in zip(arm.edit_bones, arm.bones):
            if getattr(eb, 'parent', None) is not None: b.parent = arm.bones.get(eb.parent.name)
bpy.ops.object.mode_set = mode_set
ctx = type('C', (), {'scene': None, 'collection': None})()
arm = B.create_armature(ctx, sk, 'hulk', 1.0, 'CHAIN')
anims = [a for a in f.animations if a.anim_type == 'PTRN' and any(g.name in {j.name for j in sk.joints} for g in a.groups)]
added = B.ensure_extra_bones(ctx, arm, anims)
print('extra bones created:', added)
class Sc: frame_start = 0; frame_end = 0; render = type('R', (), {'fps': 30, 'fps_base': 1.0})()
c2 = type('C', (), {'scene': Sc})()
worst = 0; n = 0; seen = set()
for a in anims:
    act, m, skipped = B.import_animation(ctx, arm, a, assign=False)
    assert not skipped, skipped
    out = B.export_action(c2, arm, act, B.ExportOptions())
    for g in a.groups:
        if g.name not in added: continue
        og = out.group(g.name); assert og is not None and og.group_id == g.group_id, g.name
        for p in ('ROT', 'TRAN'):
            c1, cc = g.channel(p), og.channel(p)
            if c1 is None: continue
            assert cc is not None, (a.name, g.name, p)
            seen.add((g.name, p, cc.kind == c1.kind))
            d1 = dict(zip(c1.frames, c1.quats() if p == 'ROT' else c1.vec3s())); d2 = dict(zip(cc.frames, cc.quats() if p == 'ROT' else cc.vec3s()))
            for fr in set(d1) & set(d2):
                a1, b1 = d1[fr], d2[fr]
                worst = max(worst, (V.qangle((a1[3],a1[0],a1[1],a1[2]), (b1[3],b1[0],b1[1],b1[2])) if p == 'ROT' else max(abs(x-y) for x, y in zip(a1, b1)))); n += 1
print('keys on extra bones round-tripped:', n, 'worst error', worst)
print(sorted(seen))
