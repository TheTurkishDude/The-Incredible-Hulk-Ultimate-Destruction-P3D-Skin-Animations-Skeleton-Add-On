from samples import sample
import sys, os, types
sys.path.insert(0, os.path.dirname(__file__))
import fakebpy
bpy = sys.modules['bpy']
# ---- extra fakes needed by ui.py
class _Base:
    def report(self, kind, msg): print('   [%s] %s' % (kind, msg)); self._reports.append((kind, msg))
bpy.types.Operator = type('Operator', (_Base,), {'_reports': []})
bpy.types.Panel = type('Panel', (), {}); bpy.types.PropertyGroup = type('PropertyGroup', (), {}); bpy.types.UIList = type('UIList', (), {})
bpy.types.Object = object; bpy.types.OperatorFileListElement = object
bpy.props.PointerProperty = lambda **k: None
sys.modules['bpy.types'] = bpy.types
eu = types.ModuleType('bpy_extras'); io = types.ModuleType('bpy_extras.io_utils')
io.ImportHelper = type('ImportHelper', (), {}); io.ExportHelper = type('ExportHelper', (), {})
sys.modules['bpy_extras'] = eu; sys.modules['bpy_extras.io_utils'] = io
import importlib
from p3d_ud_animation import p3d_core as C, blender_io as B
ui = importlib.import_module('p3d_ud_animation.ui')
# ---- mesh/object fakes
class _FS(list):
    def foreach_set(s, n, f): pass
class Mesh:
    def __init__(s, n): s.name = n; s.materials = []; s.uv_layers = types.SimpleNamespace(new=lambda name: types.SimpleNamespace(data=_FS()))
    def from_pydata(s, v, e, f): s.vertices = list(v); s.polygons = _FS(f); s.loops = list(range(3 * len(f)))
    def update(s): pass
class VG:
    def __init__(s, n): s.name = n; s.w = {}
    def add(s, idx, w, mode): s.w[idx[0]] = w
class O(dict):
    def __init__(s, n, d): super().__init__(); s.name = n; s.data = d; s.parent = None; s.type = 'MESH'
bpy.data.meshes = types.SimpleNamespace(new=Mesh)
bpy.data.materials = types.SimpleNamespace(get=lambda n: None, new=lambda n: types.SimpleNamespace(name=n))
def new_obj(n, d):
    if isinstance(d, Mesh):
        o = O(n, d); o.groups = []
        o.vertex_groups = types.SimpleNamespace(new=lambda name: (o.groups.append(VG(name)), o.groups[-1])[1])
        o.modifiers = types.SimpleNamespace(new=lambda a, b: types.SimpleNamespace(object=None)); return o
    o = fakebpy.Obj(n, d); return o
bpy.data.objects.new = new_obj
B.link_object = lambda c, o: None; B.set_active = lambda c, o: None; B.object_mode = lambda c: None
fakebpy.Obj.get = lambda s, k, d=None: dict.get(s, k, d)
# armature creation helper (edit bones -> bones)
created = {}
def mode_set(mode):
    if mode == 'OBJECT' and 'arm' in created:
        a = created['arm'].data; a.bones = fakebpy.Bones()
        for eb in a.edit_bones:
            b = fakebpy.Bone(eb.name); b.matrix_local = eb.matrix; a.bones.append(b)
bpy.ops.object.mode_set = mode_set
_o = bpy.data.objects.new
bpy.data.objects.new = lambda n, d: created.setdefault('arm', _o(n, d)) if not isinstance(d, Mesh) else _o(n, d)
# ---- scene / context
class Items(list):
    def add(s): it = types.SimpleNamespace(selected=False); s.append(it); return it
    def clear(s): del s[:]
lib = types.SimpleNamespace(path='', items=Items(), active=0, armature=None, type_filter='ALL', only_matching=False)
ctx = types.SimpleNamespace(scene=types.SimpleNamespace(p3d_lib=lib, objects=[]), object=None, collection=None)
def run(label, cls, **kw):
    print(label)
    op = cls(); op._reports = []
    for k, v in kw.items(): setattr(op, k, v)
    for k, v in cls.__annotations__.items():
        if not hasattr(op, k): setattr(op, k, {'scale': 1.0, 'flip_v': True, 'normals': True, 'use_armature': True, 'bone_mode': 'CHAIN'}.get(k))
    r = op.execute(ctx); print('   ->', r); return op, r
PATH = sys.argv[1] if len(sys.argv) > 1 else sample('global_hulk.p3d')
WANT = {'global_hulk.p3d': 'PS2', 'global_hulk_1.p3d': 'GC', 'hulkudanims.p3d': 'XBOX'}.get(os.path.basename(PATH))
ld = ui.P3D_OT_load(); ld._reports = []; ld.filepath = PATH
print('load ->', ld.execute(ctx)); print('platform:', ui._LIB['file'].polyskin().platform)
run('skin ps2 (no armature yet)', ui.P3D_OT_import_skin_ps2)
run('skin xbox on a ps2 file (must refuse)', ui.P3D_OT_import_skin_xbox)
run('skeleton', ui.P3D_OT_import_skeleton)
ctx.scene.objects.append(created['arm']); lib.armature = created['arm']
op, r = run('skin ps2 bound to armature', ui.P3D_OT_import_skin_ps2)

# ---- every platform: right importer accepts, the other two refuse
for path, plat in ((sample('global_hulk.p3d'), 'PS2'), (sample('global_hulk_1.p3d'), 'GC')):
    ld = ui.P3D_OT_load(); ld._reports = []; ld.filepath = path; ld.execute(ctx)
    res = {}
    for name, cls in (('XBOX', ui.P3D_OT_import_skin_xbox), ('PS2', ui.P3D_OT_import_skin_ps2), ('GC', ui.P3D_OT_import_skin_gc)):
        op, r = run('importer %s on a %s file' % (name, plat), cls); res[name] = r
    print('RESULT', plat, res)
    assert res[plat] == {'FINISHED'} and all(v == {'CANCELLED'} for k, v in res.items() if k != plat)
print('IMPORTER ROUTING OK')
