from samples import sample
import sys, os, types, struct, collections
sys.path.insert(0, os.path.dirname(__file__))
import fakebpy
import numpy as np
from p3d_ud_animation import p3d_core as C, p3d_convert as V, blender_io as B, p3d_skin_export as X
bpy = sys.modules['bpy']
B.link_object = lambda c, o: None; B.set_active = lambda c, o: None; B.object_mode = lambda c: None
fakebpy.Obj.get = lambda s, k, d=None: dict.get(s, k, d)
created = {}
_new = bpy.data.objects.new
bpy.data.objects.new = lambda n, d: created.setdefault('arm', _new(n, d))
def mode_set(mode):
    if mode == 'OBJECT' and 'arm' in created:
        a = created['arm'].data; a.bones = fakebpy.Bones()
        for eb in a.edit_bones:
            b = fakebpy.Bone(eb.name); b.matrix_local = eb.matrix; b.head_local = eb.head; a.bones.append(b)
        for eb, b in zip(a.edit_bones, a.bones):
            b.parent = a.bones.get(eb.parent.name) if getattr(eb, 'parent', None) is not None else None
bpy.ops.object.mode_set = mode_set
ctx = types.SimpleNamespace(scene=types.SimpleNamespace(objects=[]), selected_objects=[], collection=None)
ok = True
def check(name, cond):
    global ok; ok &= bool(cond); print(('PASS ' if cond else 'FAIL ') + name)

xb = C.P3DFile.load(sample('hulkudanims.p3d')); sk = xb.skeleton(); SCALE = 0.5
for mode in ('CHAIN', 'JOINT'):
    created.clear(); arm = B.create_armature(ctx, sk, 'hulk', SCALE, mode)
    chunk, names, nm = B.export_skeleton(arm)
    new = C.Skeleton.from_chunk(chunk)
    worst = max(max(abs(a - b) for a, b in zip(x.rest, y.rest)) for x, y in zip(new.joints, sk.joints))
    check('skeleton export (%s bones, scale %s): names/parents/rest within %.1e' % (mode, SCALE, worst),
          [j.name for j in new.joints] == [j.name for j in sk.joints] and all(a.parent == b.parent for a, b in zip(new.joints, sk.joints)) and worst < 2e-5)
    check('skeleton export (%s): masks and chains preserved' % mode, new.masks == sk.masks and new.chains == sk.chains)
# extra user bone appended + extras excluded
arm.data.bones.append(fakebpy.Bone('Extra_Wrapper')); arm.data.bones[-1].matrix_local = arm.data.bones[1].matrix_local; arm.data.bones[-1].head_local = arm.data.bones[1].head_local; arm.data.bones[-1].parent = arm.data.bones[2]
arm.data.bones[-1]['p3d_extra'] = 1
chunk, names, _ = B.export_skeleton(arm); check('p3d_extra bones are not written to the skeleton (%d joints)' % len(names), len(names) == len(sk.joints))

# ---------------------------------------------------------------- skin: fake blender mesh from the Xbox skin
V3 = lambda p: V.vscale(V.g2b_vec(p), SCALE)
class Vert:
    def __init__(s, co, groups, normal): s.co, s.groups, s.normal = co, groups, normal
class Grp:
    def __init__(s, g, w): s.group, s.weight = g, w
class Poly:
    def __init__(s): s.use_smooth = True; s.normal = (0, 0, 1)
class Tri:
    def __init__(s, v, l, mi, sn): s.vertices, s.loops, s.polygon_index, s.material_index, s.split_normals = v, l, 0, mi, sn
class FMesh:
    pass
skin = xb.polyskin(); names = [j.name for j in sk.joints]
fm = FMesh(); fm.vertices = []; fm.loop_triangles = []; uvs = []; mats = []
fm.polygons = [Poly()]
fm.calc_loop_triangles = lambda: None
for gi, g in enumerate(skin.groups):
    if g.shader not in mats: mats.append(g.shader)
    base = len(fm.vertices)
    for i, p in enumerate(g.positions):
        fm.vertices.append(Vert(V3(p), [Grp(j, w) for j, w in g.vertex_influences(i)], V.g2b_vec(g.normals[i])))
    for (a, b, c) in g.triangles():
        # blender orientation: cross . normal > 0 in blender space
        P = [fm.vertices[base + k].co for k in (a, b, c)]
        n = [fm.vertices[base + k].normal for k in (a, b, c)]
        cr = V.vcross(V.vsub(P[1], P[0]), V.vsub(P[2], P[0]))
        if V.vdot(cr, tuple(map(sum, zip(*n)))) < 0: b, c = c, b
        l0 = len(uvs)
        for k in (a, b, c):
            u, v = g.uvs[0][k]; uvs.append(types.SimpleNamespace(uv=(u, 1.0 - v)))
        fm.loop_triangles.append(Tri((base + a, base + b, base + c), (l0, l0 + 1, l0 + 2), mats.index(g.shader),
                                      [V.g2b_vec(g.normals[k]) for k in (a, b, c)]))
fm.uv_layers = types.SimpleNamespace(active=types.SimpleNamespace(data=uvs))
obj = types.SimpleNamespace(type='MESH', name='hulk_mesh', data=fm, matrix_world=fakebpy.Matrix(np.eye(4)),
                            vertex_groups=[types.SimpleNamespace(name=n) for n in names],
                            material_slots=[types.SimpleNamespace(material=types.SimpleNamespace(name=m)) for m in mats], parent=arm)
arm.matrix_world = fakebpy.Matrix(np.eye(4))
ctx.scene.objects = [arm, obj]
# vertex group index == joint index (names order)
def tri_set(g):
    P = g.positions; T = g.indices if g.platform == 'PS2' else [i for t in g.triangles() for i in t]
    return collections.Counter(frozenset(tuple(round(c, 3) for c in P[T[k + j]]) for j in range(3)) for k in range(0, len(T), 3))
def infl(g):
    return dict((tuple(round(c, 3) for c in g.positions[v]), tuple((j, round(w, 2)) for j, w in sorted(g.vertex_influences(v)))) for v in range(len(g.positions)))
src_t = collections.Counter(); src_i = {}
for g in skin.groups: src_t += tri_set(g); src_i.update(infl(g))
for platform in ('XBOX', 'PS2'):
    ck, shaders = B.build_skin_chunk(ctx, arm, names, 'hulk_skeleton', platform, 'CHILDREN', scale=SCALE)
    b = bytearray(); ck.write_into(b)
    f = C.P3DFile.parse(b'P3D\xff' + struct.pack('<II', 12, 12 + len(b)) + bytes(b)); new = f.polyskin()
    nt = collections.Counter(); ni = {}
    for g in new.groups: nt += tri_set(g); ni.update(infl(g))
    check('%s skin export from a Blender mesh: platform %s, shaders %s' % (platform, new.platform, shaders), new.platform == platform)
    check('%s skin export: triangles identical to the source in game space (%d)' % (platform, sum(nt.values())), nt == src_t)
    close = lambda a, b: all(len(a[k]) == len(b[k]) and all(x[0] == y[0] and abs(x[1] - y[1]) < 0.02 for x, y in zip(a[k], b[k])) for k in a)
    check('%s skin export: vertex weights preserved' % platform, ni.keys() == src_i.keys() and close(ni, src_i))
    # uv + normal check
    g0, s0 = new.groups[0], skin.groups[0]
    ok_uv = abs(sum(u for u, v in g0.uvs[0]) / len(g0.uvs[0]) - sum(u for u, v in s0.uvs[0]) / len(s0.uvs[0])) < 0.2
    check('%s skin export: palette limits (%s)' % (platform, [len(g.palette) for g in new.groups]),
          all(len(g.palette) <= (29 if platform == 'PS2' else 18) for g in new.groups))

# ---------------------------------------------------------------- operator level (File > Export), merge into a PS2 library
bpy.types.Operator = type('Operator', (), {'report': lambda self, k, m: (print('   [%s] %s' % (list(k)[0], m)), self._rep.append((k, m)))})
bpy.types.Panel = type('Panel', (), {}); bpy.types.PropertyGroup = type('PropertyGroup', (), {}); bpy.types.UIList = type('UIList', (), {})
bpy.types.Object = object; bpy.types.OperatorFileListElement = object
sys.modules['bpy.types'] = bpy.types
bpy.props.PointerProperty = lambda **k: None
eu = types.ModuleType('bpy_extras'); io = types.ModuleType('bpy_extras.io_utils')
io.ImportHelper = type('ImportHelper', (), {}); io.ExportHelper = type('ExportHelper', (), {})
sys.modules['bpy_extras'] = eu; sys.modules['bpy_extras.io_utils'] = io
import importlib, tempfile
ui = importlib.import_module('p3d_ud_animation.ui')
class Items(list):
    def add(s): it = types.SimpleNamespace(selected=False); s.append(it); return it
    def clear(s): del s[:]
lib = types.SimpleNamespace(path='', items=Items(), active=0, armature=arm, type_filter='ALL', only_matching=False)
ctx2 = types.SimpleNamespace(scene=types.SimpleNamespace(p3d_lib=lib, objects=[arm, obj], frame_start=0, frame_end=10,
                             render=types.SimpleNamespace(fps=30, fps_base=1.0)), object=arm, selected_objects=[obj], collection=None)
def run_export(**kw):
    op = ui.P3D_OT_export(); op._rep = []
    for k, v in ui.P3D_OT_export.__annotations__.items(): setattr(op, k, None)
    defaults = dict(export_animations=False, export_skeleton=False, skin_format='NONE', skin_source='CHILDREN', flip_v=True,
                    keep_joint_axes=True, scope='P3D', target='NEW', rot_format='AUTO', bake_all=False, reduce=0.0,
                    start_at_zero=True, all_bones=False, filepath='')
    defaults.update(kw)
    for k, v in defaults.items(): setattr(op, k, v)
    return op, op.execute(ctx2)
tmp = tempfile.mkdtemp()
ps2file = sample('global_hulk.p3d')
ui._LIB['file'] = C.P3DFile.load(ps2file); ui._LIB['path'] = ps2file
orig = ui._LIB['file']; n_orig = len(orig.items)
op, r = run_export(target='LIB', export_skeleton=True, skin_format='PS2', filepath=os.path.join(tmp, 'merged_ps2.p3d'))
check('LIB merge returns FINISHED', r == {'FINISHED'})
m = C.P3DFile.load(os.path.join(tmp, 'merged_ps2.p3d'))
ids = [i.id if isinstance(i, C.Chunk) else 'anim' for i in m.items]
print('   chunk order:', [hex(i) if i != 'anim' else i for i in ids])
check('merged file keeps texture, shaders, shadow chunks (0x19000, 0x11000, 0x10019, 0x123000)', all(x in ids for x in (0x19000, 0x11000, 0x10019, 0x123000)))
check('merged file has exactly one skeleton and one skin', ids.count(0x23000) == 1 and ids.count(0x10001) == 1)
check('merged skin is PS2 and decodes with %d triangles' % sum(len(g.indices) // 3 for g in m.polygroups) if False else 'merged skin is PS2', m.polyskin().platform == 'PS2')
sh = [C.read_str(i.payload, 0)[0] for i in m.items if isinstance(i, C.Chunk) and i.id == 0x11000]
print('   shaders in merged file:', sh)
check('shader chunks exist for every skin material', all(g.shader in sh for g in m.polyskin().groups))
check('skeleton in merged file matches the armature', len(m.skeleton().joints) == 38)
# new file with Xbox skin + skeleton + animations
ui._LIB['file'] = None
for a in [a for a in xb.animations if a.anim_type == 'PTRN' and any(g.name == 'Hip_L' for g in a.groups)][:3]:
    B.import_animation(ctx2, arm, a, assign=False)
op, r = run_export(target='NEW', export_animations=True, export_skeleton=True, skin_format='XBOX', filepath=os.path.join(tmp, 'new_xbox.p3d'))
n = C.P3DFile.load(os.path.join(tmp, 'new_xbox.p3d'))
check('new file: %d animations + skeleton + Xbox skin' % len(n.animations), len(n.animations) >= 3 and n.skeleton() is not None and n.polyskin().platform == 'XBOX')
# split mode: model chunks go to the chosen file
op, r = run_export(target='SPLIT', export_animations=True, export_skeleton=True, skin_format='PS2', filepath=os.path.join(tmp, 'model_only.p3d'))
files = sorted(os.listdir(tmp)); print('   split files:', files)
mo = C.P3DFile.load(os.path.join(tmp, 'model_only.p3d'))
check('split mode writes model file + one file per action', mo.skeleton() is not None and mo.polyskin().platform == 'PS2' and all(n + '.p3d' in files for n in ('hlk_csm_elbow_drop', 'hlk_csm_surf_kick', 'hlk_loco_BnC_sprint_n')))
op, r = run_export()
check('nothing selected -> clear error', r == {'CANCELLED'})

# ---------------------------------------------------------------- GameCube library: merge skeleton + GC skin
gcpath = sample('global_hulk_1.p3d')
ui._LIB['file'] = C.P3DFile.load(gcpath); ui._LIB['path'] = gcpath
op, r = run_export(target='LIB', export_skeleton=True, skin_format='GC', filepath=os.path.join(tmp, 'merged_gc.p3d'))
g2 = C.P3DFile.load(os.path.join(tmp, 'merged_gc.p3d'))
ids = [i.id for i in g2.items if isinstance(i, C.Chunk)]
check('GC merge: FINISHED, GameCube skin written', r == {'FINISHED'} and g2.polyskin().platform == 'GC')
check('GC merge: texture/shaders/shadow chunks preserved, one skin one skeleton', all(x in ids for x in (0x19000, 0x11000, 0x10019, 0x123000)) and ids.count(0x10001) == 1 and ids.count(0x23000) == 1)
sk_gc = g2.polyskin()
check('GC merge: skin decodes (%s)' % [(g.shader, len(g.positions), len(g.indices) // 3) for g in sk_gc.groups], sum(len(g.indices) // 3 for g in sk_gc.groups) > 3000)
# the 0x1001d chunk and the skin-level layout survive
check('GC skin chunk children order', [c.id for c in [i for i in g2.items if isinstance(i, C.Chunk) and i.id == 0x10001][0].children][-5:] == [0x122000, 0x10017, 0x1001d, 0x10003, 0x10004])
print('ALL OK' if ok else 'SOME FAILED')
