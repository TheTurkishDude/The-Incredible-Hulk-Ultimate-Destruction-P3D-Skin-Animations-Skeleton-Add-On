import sys, types, numpy as np
import importlib.util
pkg = types.ModuleType('p3d_ud_animation'); pkg.__path__ = ['/home/claude/build/p3d_ud_animation']
sys.modules['p3d_ud_animation'] = pkg      # skip __init__ (it imports the full UI)
V = importlib.import_module('p3d_ud_animation.p3d_convert')

class Vector:
    def __init__(s, v): s.v = np.array(v, float)
    def __add__(s, o): return Vector(s.v + o.v)
    def __iter__(s): return iter(s.v)
    @property
    def x(s): return s.v[0]
    @property
    def y(s): return s.v[1]
    @property
    def z(s): return s.v[2]
class Quaternion:
    def __init__(s, q): s.w, s.x, s.y, s.z = q
    def to_matrix(s):
        m = Matrix(np.eye(4)); m.m[:3, :3] = np.array(V.quat_to_mat3((s.w, s.x, s.y, s.z))); return m
class Matrix:
    def __init__(s, m): s.m = np.array(m, float)
    def to_4x4(s): return s
    def __iter__(s): return iter([tuple(r) for r in s.m])
    def __matmul__(s, o): return Matrix(s.m @ o.m)
    def inverted(s): return Matrix(np.linalg.inv(s.m))
    def to_quaternion(s):
        q = V.mat3_to_quat(tuple(map(tuple, s.m[:3, :3]))); return Quaternion(q)
    def to_translation(s): return Vector(s.m[:3, 3])
    @property
    def translation(s): return Vector(s.m[:3, 3])
    @translation.setter
    def translation(s, v): s.m[:3, 3] = v.v
class Euler: pass
mt = types.ModuleType('mathutils'); mt.Vector, mt.Quaternion, mt.Matrix, mt.Euler = Vector, Quaternion, Matrix, Euler
sys.modules['mathutils'] = mt

class KP:
    def __init__(s): s.co = [0, 0]; s.interpolation = 'BEZIER'
class KPS(list):
    def add(s, n): s.extend(KP() for _ in range(n))
    def foreach_set(s, name, flat):
        for i, k in enumerate(s): k.co = [flat[2*i], flat[2*i+1]]
class FC:
    def __init__(s, path, idx): s.data_path, s.array_index, s.keyframe_points = path, idx, KPS()
    def update(s): pass
    def evaluate(s, f):
        xs = [k.co[0] for k in s.keyframe_points]; ys = [k.co[1] for k in s.keyframe_points]
        return float(np.interp(f, xs, ys))
class FCS(list):
    def new(s, path, index=0, action_group='', group_name=''):
        fc = FC(path, index); s.append(fc); return fc
class Action(dict):
    def __init__(s, name): super().__init__(); s.name = name; s.fcurves = FCS(); s.use_fake_user = False
class Bone(dict):
    def __init__(s, name): super().__init__(); s.name = name; s.parent = None; s.matrix_local = None
class EditBone(Bone):
    head = tail = None; use_connect = False
    @property
    def matrix(s): return s._m
    @matrix.setter
    def matrix(s, m): s._m = m
class EBones(list):
    def new(s, name): e = EditBone(name); s.append(e); return e
class PB:
    def __init__(s, n): s.name = n; s.rotation_mode = 'XYZ'
class Bones(list):
    def get(s, n):
        for b in s:
            if b.name == n: return b
class Armature:
    def __init__(s, n): s.name = n; s.edit_bones = EBones(); s.bones = Bones()
class Obj(dict):
    def __init__(s, name, data): super().__init__(); s.name, s.data, s.type = name, data, 'ARMATURE'; s.animation_data = None; s.mode = 'OBJECT'
    class _P: pass
    def animation_data_create(s):
        s.animation_data = types.SimpleNamespace(action=None); return s.animation_data
    @property
    def pose(s):
        ns = types.SimpleNamespace(); ns.bones = Bones(PB(b.name) for b in s.data.bones); return ns
class Coll(list):
    def new(s, name, *a):
        o = {'armatures': Armature, 'actions': Action}[s.kind](name); s.append(o); return o
bpy = types.ModuleType('bpy')
bpy.data = types.SimpleNamespace(actions=Coll(), armatures=Coll(),
    objects=types.SimpleNamespace(new=lambda n, d: Obj(n, d)))
bpy.data.actions.kind = 'actions'; bpy.data.armatures.kind = 'armatures'
class Ops:
    def mode_set(self, mode):
        pass
bpy.ops = types.SimpleNamespace(object=Ops())
bpy.types = types.SimpleNamespace(Action=Action)
bpy.props = types.ModuleType('bpy.props')
for n in ('StringProperty','BoolProperty','IntProperty','FloatProperty','EnumProperty','CollectionProperty','PointerProperty'):
    setattr(bpy.props, n, lambda *a, **k: None)
sys.modules['bpy'] = bpy; sys.modules['bpy.props'] = bpy.props
