from samples import sample
import sys, os, struct, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
import types, importlib
pkg = types.ModuleType('p3d_ud_animation'); pkg.__path__ = [os.path.join(os.path.dirname(__file__), '..', 'p3d_ud_animation')]; sys.modules['p3d_ud_animation'] = pkg
C = importlib.import_module('p3d_ud_animation.p3d_core')
path = sys.argv[1] if len(sys.argv) > 1 else sample('hulkudanims.p3d')
raw = open(path, 'rb').read()
t = time.time()
f = C.P3DFile.parse(raw)
print('parsed in %.2fs' % (time.time() - t), len(f.items), 'items; animations:', len(f.animations))
out = f.to_bytes()
print('roundtrip identical:', out == raw, len(out), len(raw))
if out != raw:
    for i in range(min(len(out), len(raw))):
        if out[i] != raw[i]:
            print('first diff at', i); break
sk = f.skeleton(); print('skeleton', sk.name, len(sk.joints), [m[0] for m in sk.masks], [c[0] for c in sk.chains])
ps = f.polyskin(); print('skin', ps.name, ps.skeleton_name, [(g.shader, len(g.positions), len(g.triangles())) for g in ps.groups])
import collections
print(collections.Counter(a.anim_type for a in f.animations))
raws = sum(1 for a in f.animations for g in a.groups for c in g.channels if c.raw is not None)
print('undecoded channels:', raws)
