from samples import sample
import sys, os, math, random
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
import numpy as np
import types, importlib
pkg = types.ModuleType('p3d_ud_animation'); pkg.__path__ = [os.path.join(os.path.dirname(__file__), '..', 'p3d_ud_animation')]; sys.modules['p3d_ud_animation'] = pkg
C = importlib.import_module('p3d_ud_animation.p3d_core'); V = importlib.import_module('p3d_ud_animation.p3d_convert')
path = sample('hulkudanims.p3d')
f = C.P3DFile.load(path)
sk = f.skeleton()
rest = V.build_rest(sk.joints, 1.0)

def q2m(q):  # wxyz -> 3x3
    return np.array(V.quat_to_mat3(q))

# ---- 1. rest FK in game space equals blender-space rest (via axis swap)
Wg = [None]*len(sk.joints)
for i, j in enumerate(sk.joints):
    m = np.array(j.rest).reshape(4, 4)
    Wg[i] = m if i == 0 else m @ Wg[j.parent]
err = 0
for i, r in enumerate(rest):
    pg = Wg[i][3, :3]
    err = max(err, np.abs(np.array(V.g2b_vec(pg)) - np.array(r.wt)).max())
print('rest world position error', err)

# ---- 2. rotation conversion consistency: R_b = S R_g S
S = np.array([[1,0,0],[0,0,1],[0,1,0]], float)
e = 0
for i, j in enumerate(sk.joints):
    Rg = np.array(j.rest).reshape(4, 4)[:3,:3].T          # column-vector game rotation
    Rb_expected = S @ Rg @ S
    Rb = q2m(rest[i].q)
    e = max(e, np.abs(Rb - Rb_expected).max())
print('rotation conversion error', e)

# ---- 3. bone planning orthonormal + C consistency
for mode in ('CHAIN', 'JOINT'):
    plans = V.plan_bones(rest, mode)
    dev = 0
    for r, p in zip(rest, plans):
        R = q2m(p['q'])
        dev = max(dev, np.abs(R.T @ R - np.eye(3)).max(), abs(np.linalg.det(R) - 1))
        Rc = q2m(V.qmul(r.wq, p['c']))
        dev = max(dev, np.abs(Rc - R).max())
    print(mode, 'frame deviation', dev, 'lengths', min(p['length'] for p in plans), max(p['length'] for p in plans))

# ---- 4. FK equivalence with a real animation (the important test)
anim = [a for a in f.animations if a.name == 'hlk_csm_elbow_drop'][0]
frame_idx = 10
def sample(ch, kinds_q, fr):
    # nearest-previous key (keys exact for chosen frame list)
    fs = ch.frames
    k = max(i for i, x in enumerate(fs) if x <= fr) if fs[0] <= fr else 0
    return k
nj = len(sk.joints)
for mode in ('CHAIN', 'JOINT'):
    plans = V.plan_bones(rest, mode)
    # game-space FK
    Lg = []
    for i, j in enumerate(sk.joints):
        m = np.array(j.rest).reshape(4, 4).copy()
        g = anim.group(j.name)
        if g is not None:
            ch = g.channel('ROT')
            if ch is not None:
                k = sample(ch, None, frame_idx)
                x, y, z, w = ch.quats()[k]
                Rc = np.array(V.quat_to_mat3((w, x, y, z)))
                m[:3,:3] = Rc.T
            ch = g.channel('TRAN')
            if ch is not None:
                k = sample(ch, None, frame_idx)
                m[3,:3] = ch.vec3s()[k]
        Lg.append(m)
    Wgame = [None]*nj
    for i, j in enumerate(sk.joints):
        Wgame[i] = Lg[i] if i == 0 else Lg[i] @ Wgame[j.parent]
    # blender-space pose FK through bone frames
    pose_q = []; pose_t = []
    for i, j in enumerate(sk.joints):
        g = anim.group(j.name)
        r = rest[i]; c = plans[i]['c']
        q = r.q; t = r.t
        bq = V.IDENT_Q; bt = (0, 0, 0)
        if g is not None:
            ch = g.channel('ROT')
            if ch is not None:
                k = sample(ch, None, frame_idx)
                bq = V.rot_track_game_to_pose([ch.quats()[k]], r.q, c)[0]
            ch = g.channel('TRAN')
            if ch is not None:
                k = sample(ch, None, frame_idx)
                bt = V.loc_track_game_to_pose([ch.vec3s()[k]], r.q, r.t, c)[0]
            # absent channel -> identity offset
        pose_q.append(bq); pose_t.append(bt)
    # bone-frame rest (bone matrix_local) and pose chain:  M_pose = parent_pose * (parent_rest^-1 * rest) * B
    Wb_rest_q = [p['q'] for p in plans]; Wb_rest_t = [p['head'] for p in plans]
    worldq = [None]*nj; worldt = [None]*nj
    for i, j in enumerate(sk.joints):
        # local rest of bone relative to parent bone
        if i == 0 or rest[i].parent < 0:
            lq = Wb_rest_q[i]; lt = Wb_rest_t[i]
            pq, pt = V.IDENT_Q, (0, 0, 0)
        else:
            p = rest[i].parent
            pinv = V.qconj(Wb_rest_q[p])
            lq = V.qmul(pinv, Wb_rest_q[i]); lt = V.qrot(pinv, V.vsub(Wb_rest_t[i], Wb_rest_t[p]))
            pq, pt = worldq[p], worldt[p]
        # apply pose offset B
        cq = V.qmul(lq, pose_q[i]); ct = V.vadd(lt, V.qrot(lq, pose_t[i]))
        worldq[i] = V.qmul(pq, cq); worldt[i] = V.vadd(pt, V.qrot(pq, ct))
    # compare positions to game FK converted
    e = 0
    for i in range(nj):
        pg = Wgame[i][3,:3]
        e = max(e, np.abs(np.array(V.g2b_vec(pg)) - np.array(worldt[i])).max())
    # compare orientation: world bone frame = joint world frame * C
    eo = 0
    for i in range(nj):
        Rg = Wgame[i][:3,:3].T                      # game column rotation of the joint world
        Rb = S @ Rg @ S                              # blender joint world rot
        Rbone = q2m(worldq[i])
        Rexp = Rb @ q2m(plans[i]['c'])
        eo = max(eo, np.abs(Rbone - Rexp).max())
    print(mode, 'FK position error', e, ' orientation error', eo)

# ---- 5. export math roundtrip
rt = 0
plans = V.plan_bones(rest, 'CHAIN')
for g in anim.groups:
    i = sk.index_of(g.name)
    if i < 0: continue
    r = rest[i]; c = plans[i]['c']
    ch = g.channel('ROT')
    if ch is not None:
        q = ch.quats()
        pose = V.rot_track_game_to_pose(q, r.q, c)
        back = V.rot_pose_to_game(pose, r.q, c)
        for a, b in zip(q, back):
            rt = max(rt, V.qangle((a[3],a[0],a[1],a[2]), (b[3],b[0],b[1],b[2])))
    ch = g.channel('TRAN')
    if ch is not None:
        v = ch.vec3s()
        pose = V.loc_track_game_to_pose(v, r.q, r.t, c, 1.0)
        back = V.loc_pose_to_game(pose, r.q, r.t, c, 1.0)
        for a, b in zip(v, back):
            rt = max(rt, max(abs(a[k]-b[k]) for k in range(3)))
print('pose roundtrip max error', rt)

# ---- 6. quantiser roundtrip
random.seed(1); worst = 0
for _ in range(2000):
    q = V.qnorm((random.gauss(0,1),)*0 + tuple(random.gauss(0,1) for _ in range(4)))
    ints = C.quat_quant(q[1], q[2], q[3], q[0], 16)
    x, y, z, w = C.quat_dequant(*ints, 16)
    s = 1 if q[0] >= 0 else -1
    worst = max(worst, V.qangle((w,x,y,z), (q[0]*s,q[1]*s,q[2]*s,q[3]*s)))
print('16 bit quantisation worst angle (rad)', worst)

# ---- 7. frame / numFrames relation
bad = 0
for a in f.animations:
    if a.anim_type != 'PTRN': continue
    mx = max((max(c.frames) for g in a.groups for c in g.channels if c.frames), default=0)
    if int(a.num_frames) != mx + 1: bad += 1
print('PTRN anims where numFrames != maxKey+1:', bad)
