from samples import sample
import sys, os, struct, collections, types, importlib
sys.path.insert(0, os.path.dirname(__file__))
root = os.path.join(os.path.dirname(__file__), '..')
pkg = types.ModuleType('p3d_ud_animation'); pkg.__path__ = [os.path.join(root, 'p3d_ud_animation')]; sys.modules['p3d_ud_animation'] = pkg
C = importlib.import_module('p3d_ud_animation.p3d_core'); X = importlib.import_module('p3d_ud_animation.p3d_skin_export')
xb = C.P3DFile.load(sample('hulkudanims.p3d')); ps = C.P3DFile.load(sample('global_hulk.p3d'))
ok = True
def check(name, cond):
    global ok; ok &= bool(cond); print(('PASS ' if cond else 'FAIL ') + name)

# ---------------------------------------------------------------- 1. skeleton chunk byte exact
for label, f in (('xbox', xb), ('ps2', ps)):
    sk = f.skeleton(); orig = sk.chunk
    mine = X.skeleton_chunk(sk.name, [(j.name, j.parent, j.rest) for j in sk.joints], sk.masks, sk.chains)
    a, b = bytearray(), bytearray(); orig.write_into(a); mine.write_into(b)
    check('skeleton chunk byte-exact (%s)' % label, a == b)

# ---------------------------------------------------------------- 2. Xbox group: every fixed field vs original
skin_chunk = [i for i in xb.items if isinstance(i, C.Chunk) and i.id == 0x10001][0]
ogroups = [c for c in skin_chunk.children if c.id == 0x10020]
dec = xb.polyskin()
for gi, (oc, dg) in enumerate(zip(ogroups, dec.groups)):
    kd = {k.id: k for k in oc.children}
    g = X.SkinGroup(dg.shader); g.flags = dg.flags; g.palette = list(dg.palette)
    srcs = kd[0x10010].payload[4:]
    ml = kd[0x1000b].payload[4:]; wts = struct.unpack_from('<%df' % (3 * len(dg.positions)), kd[0x1000c].payload, 4)
    for i, p in enumerate(dg.positions):
        w4 = list(wts[3*i:3*i+3]); w4.append(1.0 - sum(w4)); infl = []
        for k in range(4):
            if w4[k] > 1e-5: infl.append((dg.palette[ml[4*i + 3 - k]], w4[k]))
        g.verts.append(X.SkinVertex(p, dg.normals[i], dg.uvs[0][i], infl, srcs[i]))
    mine = X.xbox_group_chunk(g, indices=list(dg.indices))
    md = {k.id: k for k in mine.children}
    same = all(md[i].payload == kd[i].payload for i in (0x10011, 0x10005, 0x10010, 0x10006, 0x10007, 0x1000d, 0x1000a, 0x10003))
    check('xbox group %d: pos/nrm/uv/palette/indices/bbox/sphere/0x10010 byte-exact' % gi, same)
    if not same:
        print('    differing children:', [hex(i) for i in (0x10011, 0x10005, 0x10010, 0x10006, 0x10007, 0x1000d, 0x1000a, 0x10003, 0x10004) if md[i].payload != kd[i].payload])
    check('xbox group %d: child order + header' % gi, [k.id for k in mine.children] == [k.id for k in oc.children] and mine.payload == oc.payload)
    # weights: compare semantic (influence order of ties may differ)
    ml_o, wt_o = kd[0x1000b].payload, kd[0x1000c].payload
    sp_o = struct.unpack('<4f', kd[0x10004].payload); sp_m = struct.unpack('<4f', md[0x10004].payload)
    check('xbox group %d: sphere (float rounding only)' % gi, all(abs(a - b) < 1e-5 for a, b in zip(sp_o, sp_m)))
    # weights: same influences per vertex (the original keeps stale indices in unused slots)
    def infl_of(chunks, i):
        ml = chunks[0x1000b].payload[4:]; wt = struct.unpack_from('<3f', chunks[0x1000c].payload, 4 + 12 * i)
        w4 = list(wt) + [1.0 - sum(wt)]
        return dict((dg.palette[ml[4*i + 3 - k]], round(w4[k], 5)) for k in range(4) if w4[k] > 1e-5)
    check('xbox group %d: weights identical per vertex' % gi, all(infl_of(md, i) == infl_of(kd, i) for i in range(len(g.verts))))

# ---------------------------------------------------------------- 3. PS2 stream vs original (raw packets)
pskin = [i for i in ps.items if isinstance(i, C.Chunk) and i.id == 0x10001][0]
for gi, oc in enumerate([c for c in pskin.children if c.id == 0x10020]):
    p = [k for k in oc.children if k.id == 0x10012][0].payload
    pal = list(struct.unpack_from('<%dI' % struct.unpack_from('<I', [k for k in oc.children if k.id == 0x1000d][0].payload, 0)[0], [k for k in oc.children if k.id == 0x1000d][0].payload, 4))
    verts, packets, cur = [], [], None
    for addr, num, o in C.vif_unpacks(p):
        if addr == 0: cur = {}; packets.append(cur)
        elif addr == 3: cur['uv'] = struct.unpack_from('<%dI' % (2 * num), p, o)
        elif addr == 4: cur['nrm'] = struct.unpack_from('<%dh' % (3 * num), p, o)
        elif addr == 5: cur['pos'] = struct.unpack_from('<%df' % (3 * num), p, o)
        elif addr == 6: cur['idx'] = p[o:o + 4 * num]
        elif addr == 7: cur['wt'] = struct.unpack_from('<%dh' % (4 * num), p, o)
    pk_in = []
    for x in packets:
        n = len(x['pos']) // 3; lst = []
        for v in range(n):
            ub, vb = x['uv'][2 * v], x['uv'][2 * v + 1]
            adc = bool(ub & 1 and vb & 1)
            uv = struct.unpack('<2f', struct.pack('<2I', ub & ~1, vb & ~1))
            infl = []; w = 0.0
            for k in range(4):
                a = x['wt'][4 * v + k] / 4096.0
                w = a if k == 0 else w * a
                if w <= 0: break
                infl.append((pal[x['idx'][4 * v + k] // 4], w))
            verts.append(X.SkinVertex(tuple(x['pos'][3*v:3*v+3]), tuple(c / 4096.0 for c in x['nrm'][3*v:3*v+3]), uv, infl, 0))
            lst.append((len(verts) - 1, adc))
        pk_in.append(lst)
    nmat = len(pal); cap = X.ps2_capacity(nmat)
    mine = X.ps2_stream(pk_in, verts, pal, cap)
    orig_trim = p.rstrip(b'\0')[12:]
    mine_trim = mine.rstrip(b'\0')[12:]
    # header words 0,1 and everything up to the last MSCNT must be identical
    check('ps2 group %d: capacity formula (%d verts/packet)' % (gi, cap), cap == max(len(x) for x in pk_in))
    check('ps2 group %d: VIF stream byte-exact (up to trailing padding)' % gi, mine_trim == orig_trim)
    if mine_trim != orig_trim:
        for i in range(min(len(mine_trim), len(orig_trim))):
            if mine_trim[i] != orig_trim[i]: print('   first diff at', hex(i), mine_trim[i-4:i+8].hex(' '), orig_trim[i-4:i+8].hex(' ')); break
        print('   lens', len(mine_trim), len(orig_trim))
    check('ps2 group %d: header size fields' % gi, struct.unpack_from('<2I', mine, 0) == struct.unpack_from('<2I', p, 0))
    # group chunk fields
    oc_kd = {k.id: k for k in oc.children}
    check('ps2 group %d: 0x10014 constant' % gi, oc_kd[0x10014].payload == X.PS2_PKT_INFO)
    nv = sum(len(q) for q in pk_in) - 2 * len(pk_in) + 2
    check('ps2 group %d: vertex-count header field' % gi, struct.unpack_from('<I', oc.payload, len(oc.payload) - 36 + 8)[0] == nv)
    g = X.SkinGroup('x'); g.verts = verts
    mn, mx, c, r = X.bounds(verts)
    bb = struct.unpack('<6f', oc_kd[0x10003].payload); sp = struct.unpack('<4f', oc_kd[0x10004].payload)
    close = lambda a, b: all(abs(x - y) < 1e-4 for x, y in zip(a, b))
    check('ps2 group %d: bbox + sphere formulas' % gi, close(bb, mn + mx) and close(sp, c + (r,)))

# ---------------------------------------------------------------- 3b. GameCube group: re-encode raw arrays
gcf = C.P3DFile.load(sample('global_hulk_1.p3d'))
gskin = [i for i in gcf.items if isinstance(i, C.Chunk) and i.id == 0x10001][0]
for gi, oc in enumerate([c for c in gskin.children if c.id == 0x10020]):
    kd = {k.id: k for k in oc.children}; fm = C.gc_parse_format(kd[0x10014].payload[12:]); arr = kd[0x10012].payload[12:]; dl = kd[0x10013].payload[12:]
    P, N, T = fm['pos'], fm['nrm'], fm['tex']; width = 1 if P['vcd'] == 2 else 2
    recs = [arr[8 * i:8 * i + 8] for i in range(fm['nrec'])]
    pos = struct.unpack_from('>%dh' % (3 * P['count']), arr, P['offset']); pos = [tuple(pos[i:i + 3]) for i in range(0, len(pos), 3)]
    nrm = struct.unpack_from('>%db' % (3 * N['count']), arr, N['offset']); nrm = [tuple(nrm[i:i + 3]) for i in range(0, len(nrm), 3)]
    tex = struct.unpack_from('>%dH' % (2 * T['count']), arr, T['offset']); tex = [tuple(tex[i:i + 2]) for i in range(0, len(tex), 2)]
    cmds = []; o = 0
    while o < len(dl):
        if dl[o] == 0: o += 1; continue
        n = struct.unpack_from('>H', dl, o + 1)[0]; o += 3; lst = []
        for v in range(n):
            q = o + v * 3 * width
            lst.append(tuple(dl[q + k] if width == 1 else (dl[q + 2 * k] << 8) | dl[q + 2 * k + 1] for k in range(3)))
        o += n * 3 * width; cmds.append(lst)
    pal = list(struct.unpack_from('<%dI' % struct.unpack_from('<I', kd[0x1000d].payload, 0)[0], kd[0x1000d].payload, 4))
    dg = gcf.polyskin().groups[gi]
    vs = [X.SkinVertex(p, (0, 1, 0), (0, 0), [(0, 1.0)]) for p in dg.positions]
    mine = X.gc_build_group(dg.shader, dg.flags, pal, recs, pos, nrm, tex, cmds, width, vs)
    md = {k.id: k for k in mine.children}
    check('gc group %d: header + child order' % gi, mine.payload == oc.payload and [k.id for k in mine.children] == [k.id for k in oc.children])
    for cid, nm in ((0x10014, 'vertex format'), (0x10012, 'arrays'), (0x10013, 'display list'), (0x1000d, 'palette')):
        check('gc group %d: %s byte-exact (%d bytes)' % (gi, nm, len(kd[cid].payload)), md[cid].payload == kd[cid].payload)
    bb = struct.unpack('<6f', kd[0x10003].payload); mb = struct.unpack('<6f', md[0x10003].payload)
    check('gc group %d: bbox within quantisation' % gi, all(abs(a - b) < 1e-3 for a, b in zip(bb, mb)))
gsk = gcf.polyskin()
ck = X.polyskin_chunk('GC', 'hulk_skin', 'hulk_skeleton', X.groups_from_decoded(gsk))
check('gc polyskin: top-level child ids match the original', [k.id for k in ck.children][:1] + [k.id for k in ck.children][-5:] == [k.id for k in gskin.children][:1] + [k.id for k in gskin.children][-5:])
check('gc polyskin: 0x10021 / 0x122000 / 0x10017 / 0x1001d constants', all(next(k for k in ck.children if k.id == i).payload == next(k for k in gskin.children if k.id == i).payload for i in (0x10021, 0x122000, 0x10017, 0x1001d)))

# ---------------------------------------------------------------- 4. full pipeline: decode -> export (both platforms) -> decode
Q = lambda p: tuple(int(round(c * 4096)) for c in p)      # key on the GameCube grid so every platform compares equal
def tri_set(g):
    P = g.positions
    T = g.indices if g.platform in ('PS2', 'GC') else [i for t in g.triangles() for i in t]
    return collections.Counter(frozenset(Q(P[T[k + j]]) for j in range(3)) for k in range(0, len(T), 3))
def infl_map(g):
    m = {}
    for v in range(len(g.positions)):
        m[(Q(g.positions[v]),)] = tuple((j, round(w, 3)) for j, w in sorted(g.vertex_influences(v)))
    return m
def roundtrip(src_skin, platform, maxpal, label):
    srcgroups = X.groups_from_decoded(src_skin)
    mats = [(g.shader, g.verts, g.tris) for g in srcgroups]
    groups = X.build_groups(mats, maxpal, max_inf=(3 if platform == 'GC' else 4))
    ck = X.polyskin_chunk(platform, 'hulk_skin', 'hulk_skeleton', groups)
    b = bytearray(); ck.write_into(b)
    f = C.P3DFile.parse(b'P3D\xff' + struct.pack('<II', 12, 12 + len(b)) + bytes(b))
    new = f.polyskin()
    check('%s: platform detected %s' % (label, platform), new.platform == platform)
    ta = collections.Counter(); tb = collections.Counter()
    for g in src_skin.groups: ta += tri_set(g)
    for g in new.groups: tb += tri_set(g)
    check('%s: %d groups, triangles preserved (%d vs %d, identical %d)' % (label, len(new.groups), sum(ta.values()), sum(tb.values()), sum((ta & tb).values())), ta == tb)
    check('%s: palette limit %d respected (max %d)' % (label, maxpal, max(len(g.palette) for g in new.groups)), all(len(g.palette) <= maxpal for g in new.groups))
    ia = {}; ib = {}
    for g in src_skin.groups: ia.update(infl_map(g))
    for g in new.groups: ib.update(infl_map(g))
    def same(a, b): return a.keys() == b.keys() and all(len(a[k]) == len(b[k]) and all(x[0] == y[0] and abs(x[1] - y[1]) < 0.004 for x, y in zip(a[k], b[k])) for k in a)
    if platform == 'GC' or label.startswith('gc'):
        # 3 influences max + 4096/64 fixed point: compare dominant influence only
        dom = lambda d: dict((k, max(v, key=lambda t: t[1])[0] if v else None) for k, v in d.items())
        agree = sum(1 for k in ia if k in ib and ia[k] and ib[k] and max(ia[k], key=lambda t: t[1])[0] == max(ib[k], key=lambda t: t[1])[0])
        check('%s: dominant bone preserved for %.1f%% of %d vertices' % (label, 100.0 * agree / len(ia), len(ia)), agree > 0.97 * len(ia))
    else:
        check('%s: skin weights preserved for all %d vertices' % (label, len(ia)), same(ia, ib))
    # strip validity: every drawn triangle winding agrees with normals
    for g in new.groups:
        P = g.positions; N = g.normals
        T = g.indices if g.platform == 'PS2' else [i for t in g.triangles() for i in t]
    return new
for name, src in (('xbox', xb.polyskin()), ('ps2', ps.polyskin()), ('gc', gcf.polyskin())):
    for platform, mp in (('XBOX', X.XBOX_MAX_PALETTE), ('PS2', X.PS2_MAX_PALETTE), ('GC', X.GC_MAX_PALETTE)):
        roundtrip(src, platform, mp, '%s skin -> %s' % (name, platform))
roundtrip(xb.polyskin(), 'GC', 6, 'xbox skin -> GC with tiny palette (forces group splitting)')
roundtrip(ps.polyskin(), 'PS2', 6, 'ps2 skin -> PS2 with tiny palette (forces group splitting)')
roundtrip(xb.polyskin(), 'XBOX', 6, 'xbox skin -> XBOX with tiny palette')
print('ALL OK' if ok else 'SOME FAILED')
