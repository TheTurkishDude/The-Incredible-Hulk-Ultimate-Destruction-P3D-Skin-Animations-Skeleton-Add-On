"""Locate the game files used by the tests (they are not part of the repository).
Set P3D_SAMPLES to a folder containing hulkudanims.p3d (Xbox), global_hulk.p3d (PS2) and global_hulk_1.p3d (GameCube)."""
import os
ROOT = os.environ.get('P3D_SAMPLES', '/mnt/user-data/uploads')


def sample(name):
    p = os.path.join(ROOT, name)
    if not os.path.exists(p):
        raise SystemExit('missing sample file %s  (set the P3D_SAMPLES environment variable)' % p)
    return p
