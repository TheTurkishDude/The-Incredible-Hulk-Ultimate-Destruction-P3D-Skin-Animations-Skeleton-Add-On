"""Runs every test script and prints a summary.   usage:  P3D_SAMPLES=/path/to/files python tests/run_all.py"""
import os, subprocess, sys
here = os.path.dirname(os.path.abspath(__file__))
names = ['test_core', 'test_convert', 'test_blender_layer', 'test_extra_bones', 'test_skin_ps2', 'test_ui_flow',
         'test_export_codecs', 'test_export_blender']
bad = 0
for n in names:
    r = subprocess.run([sys.executable, os.path.join(here, n + '.py')], capture_output=True, text=True)
    out = r.stdout + r.stderr
    failed = r.returncode != 0 or 'FAIL' in out or 'Traceback' in out
    print('%-22s %s' % (n, 'FAILED' if failed else 'ok'))
    if failed:
        bad += 1
        print(out[-1500:])
sys.exit(1 if bad else 0)
