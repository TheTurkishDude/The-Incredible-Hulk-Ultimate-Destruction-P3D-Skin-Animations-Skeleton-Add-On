# Pure3D (.p3d) – Hulk: Ultimate Destruction animation file analysis (hulkudanims.p3d)

File: `P3D\xff | u32 header_size=12 | u32 file_size | chunks`. Chunk = `u32 id | u32 data_size | u32 total_size | payload | children`.
Strings = `u8 len (padded to x4) + chars`. Everything little endian. 285 top-level chunks:
283 Animation (0x121000), 1 Skeleton (0x23000), 1 PolySkin (0x10001). Re-serialising the whole file is byte-identical.

## Animation 0x121000
`u32 ver | name | fourcc type | f32 numFrames | f32 fps(30) | u32 cyclic`
Types: PTRN 193 (skeletal / transform), CAM 36, BQG 28, VRTX 10, PVIS 7, SHAD 6, TEX 3.
Children, in order: `0x121006 AnimationSize`, `0x121002 GroupList`, `0x121401 region`*, `0x121402 tail`.
* AnimationSize: `ver, numGroups`, optional `0x121400 (ver, numRegions)`, then one `0x121007 (ver, channelKindId, count, u16 keyCount[count])`
  per channel kind present (ascending id, channels in group order). Bool channels count states (nk, +1 if first toggle frame != 0).
  The add-on regenerates it on every write.
* Group 0x121001: `ver, name, groupId (= skeleton joint index), numChannels`; children are channels. Group names == skeleton joint names
  (38 joints, 36 of them in nearly every PTRN clip) and == vertex group names of the skin.
* Region 0x121401: `name ("left_leg"/"right_leg"), ver, count, count x (f32 start, f32 end)` – leg-lock / foot-plant frame ranges.

## Channels (all: `u32 ver, char[4] param`, optional 0x121110 interpolation child `(ver, mode)`)
| id | kind | layout after param |
|---|---|---|
| 0x121100 | Float1 | nk u32, u16 frames[nk], f32[nk] |
| 0x121101 | Float2 | same, 2 floats per key |
| 0x121102 | Vector1DOF | u16 mapping, f32 const[3], nk, frames, f32[nk] |
| 0x121103 | Vector2DOF | mapping (0=XY,1=XZ,2=YZ), const[3], nk, frames, 2 f32 per key |
| 0x121104 | Vector3 (TRAN/LOOK/UP) | nk, frames, 3 f32 per key |
| 0x121105 | Quaternion | nk, frames, 4 f32 (x,y,z,w) |
| 0x121107 | String (TEX) | nk, frames, strings |
| 0x121108 | Bool (VIS/DFEN) | u16 startState, nk, frames (toggle frames) |
| 0x121109 | Colour | nk, frames, u32 RGBA |
| 0x12110e | Int | nk, frames, u32 |
| **0x121112** | **Quat 16 bit ('ROT')** | nk, frames, 3 x int16 (x,y,z)/32767, w = sqrt(1-x²-y²-z²) ≥ 0 |
| **0x121114** | **Quat 8 bit ('ROT')** | nk, frames, 3 x int8 (x,y,z)/127, w rebuilt |
Skeletal clips use `ROT` (quat16/quat8, key frames are sparse u16 frame numbers) and `TRAN` (Vector3 or 1/2 DOF). A joint
without a TRAN channel keeps its rest translation. Quaternion = rotation of the *transposed* stored row-major matrix (verified: static
channels equal the rest pose, median error 0°).

## Skeleton 0x23000
`name, ver, numJoints(38), numMasks(3), numChains(2)`; joint 0x23001 = `name, parent u32, 16 f32 row-major local rest matrix
(row vectors, translation in last row, rigid)`; 0x23002 body-part bit masks (upper_body, upper_body2, lower_body);
0x23003 leg chains (left_leg: joints 4,5,6; right_leg: 8,9,10) – the names used by the animation regions.

## PolySkin 0x10001 (hulk_skin, 4 prim groups: Hulk_Skin x3, Hulk_Shorts)
Prim group 0x10020: `ver, shader, primType (1 = triangle strip), flags, nVerts, nIdx, nMatrices, 4 u32` with children
positions 0x10005, normals 0x10006, uv 0x10007, matrix list 0x1000b (4 palette bytes / vertex), weights 0x1000c (3 floats, 4th = 1-sum),
palette 0x1000d (palette index -> skeleton joint), indices 0x1000a, 0x10010 (1 byte/vertex, kept untouched).
**The 4 matrix bytes are in reverse order of the weights** (weight k ↔ byte 3-k) – verified by distance of every vertex to its bones.

## Coordinates
Game: Y up, character faces -Z, left = +X (mirrored handedness). Blender: `(x,y,z) -> (x,z,y)` (a reflection, triangle winding is
flipped automatically), quaternion `(x,y,z,w) -> (w,-x,-z,-y)`.
Pose offset in Blender: `B = Lrest⁻¹·L(t)` expressed in the bone frame (`C⁻¹ B C`), so bones may point along the chain while the data stays exact.

## PS2 skin (global_hulk.p3d)
No skeleton chunk (joint names come from the Xbox/animation file's skeleton; palette 0x1000d maps palette slot -> joint index).
Prim group 0x10020 holds a **0x10012 VIF packet stream** (12 byte header, then PS2 VIF codes: FLUSHA, BASE, OFFSET, STCOL, STCYCL, STMASK,
STMOD/STROW, UNPACK, MSCNT). Every packet = up to 48-54 vertices of one triangle strip (GIF tag PRIM=4, regs ST/RGBAQ/XYZ2):

| VU addr | UNPACK | content |
|---|---|---|
| 0 | V4-32 x3 | packet header (vertex count, GIF tag) |
| 3 | V2-32 | UV floats. **Lowest mantissa bit of U and V both set = GS ADC flag** (the triangle completed by that vertex is not drawn = strip restart) |
| 4 | V3-16 | normal / 4096 |
| 5 | V3-32 | position (same game space as Xbox) |
| 6 | V4-8 | matrix slot x 4 (palette index = byte / 4); STMOD=1 adds ROW = VU matrix base (908/996) |
| 7 | V4-16 | chained weights /4096: w0 = a0, w(k) = w(k-1) * a(k) (sum = 1) |

Verified: 3068 body triangles = Xbox 1529+1282+257, identical total surface area, mean vertex-bone distance 0.324 like the Xbox data.
Strips contain duplicated vertices, so vertices are welded by (pos, uv, normal, bones, weights).

## Export notes (what the exporters write, and what is inferred)
* **Skeleton 0x23000**: joints (parent first, root parent 0), local rest = row-major row-vector matrix; masks/chains are kept when the joint list is unchanged.
  Re-exporting the imported skeleton is byte-identical to the original chunk.
* **Xbox skin**: group = `ver, shader, 1 (strip), flags, nVerts, nIdx, nPalette, 0,1,0,0` + children 0x10011, 0x10005, 0x10010, 0x10006, 0x10007,
  0x1000b, 0x1000c, 0x1000d, 0x1000a, 0x10003 (bbox), 0x10004 (centre = bbox centre, radius = half diagonal). Byte-identical to the original for
  positions/normals/uv/palette/indices/bounds. Matrix bytes are reversed against the weights (weight k <-> byte 3-k), unused slots are written as 0
  (the original leaves stale indices there, weight 0).  `0x10010` (1 byte/vertex) is undecoded: it is written as the low byte of the source vertex id.
* **PS2 skin**: stream = `[0x00100007, size of first packet, total size]` + `FLUSHA, BASE 0x11, OFFSET (490-2*nPalette), STCOL(1,0,0,0)` + packets.
  Packet = UNPACK hdr(3 QW: n, 3, 3+5*cap, ROW-27 / 0,0,0,-1 / n|0x8000, GIF 0x30024000, 0x412), STCYCL 5, masked UNPACKs addr 3 (uv), 4 (normal),
  5 (position), STMOD 1 + STROW(ROW) + UNPACK V4-8 addr 6, STMOD 0, UNPACK V4-16 addr 7, STCYCL 1, MSCNT (NOP for the first packet).
  ROW = 1024 - 4*nPalette (matrices sit at the top of VU1 memory), cap = vertices per packet = multiple of 6 <= (446-2*nPalette)/8 (48 for 29 matrices,
  54 for 7). Strips alternate winding by their position inside the packet; restarts flag the first two vertices (ADC) and start on an even vertex.
  Header field "nVerts" of the group = sum(packet vertices) - 2*packets + 2. Verified byte-identical against both groups of global_hulk.p3d
  (everything except trailing NOP padding, which the exporter only aligns to 16 bytes).
* **Not verifiable without the game/hardware**: whether the PS2 microcode accepts packet sizes/palettes outside the two observed combinations
  (the exporter stays inside them: <= 29 matrices, capacity formula fitted to both groups). Treat PS2 skin export as experimental and test it in game.

## GameCube skin (global_hulk_1.p3d)
Same chunk skeleton as the other platforms (`0x10001` PolySkin, `0x10020` groups with `0x1000d` palette, `0x10003` bbox, `0x10004` sphere) plus
the GX specific chunks below. The group header is `ver, shader, 1, flags, nStripVerts, 0, nPalette, 1, 1, 0, 0`; the skin chunk has the extra child
`0x1001d` (13 constant bytes) after `0x10017`, and `0x10021` is the Xbox style constant. Told apart from PS2 by the magic of `0x10012`:
`0x00030003` = GameCube, `0x00100007` = PS2.

| chunk | content |
|---|---|
| `0x10014` | vertex format (60 bytes: `0x30003, 0x30, 0x30` + 48): `u32 0, u32 0xff, BE nRecords`, then for position / normal / uv0: `BE offset, GX attr (9/10/13), GX_INDEX8(2)/INDEX16(3), count code, component type, fraction bits, stride, BE count` |
| `0x10012` | arrays (`0x30003, size, size` + data): **weight records** (`npos + nnrm` x 8 bytes), **positions** s16 BE / 2^12, **normals** s8 / 2^6, **uv** u16 BE / 2^15 |
| `0x10013` | display list (`0x30003, size, size` + data): `0x98` GX_DRAW_TRIANGLE_STRIP, BE u16 vertex count, per vertex `(pos idx, nrm idx, uv idx)` as 8 or 16 bit big endian indices, zero padded to 32 bytes |

* **Weight record** (8 bytes): `count, slot0, slot1, slot2, BE u16 w0, BE u16 w1` with weights / 32768; the third weight is the remainder; slots index the
  group palette (`0x1000d`). Max 3 influences (the PS2/Xbox data has 4). The first `npos` records belong to the positions, the next `nnrm` to the normals
  (normal records are identical to the record of the vertex that uses them in the original data).
* The offset of the position array equals `nRecords * 8`; the three arrays are stored back to back.
* Strips alternate winding by their position inside the command like Xbox/PS2 (even = as written); the original joins strips with duplicated vertices.
* Verified: both groups re-encode **byte-identically** (format, arrays, display list, palette, header), and the decoded mesh equals the PS2 mesh of the same
  model (2001 / 266 welded vertices, 3068 / 358 triangles, positions within 0.0004; the only weight differences are PS2 vertices with a 4th influence).
* Limits of the format used by the exporter: positions within +-8 units, UVs 0..2 (unsigned), 3 influences, palette <= 29 (largest observed), index width
  16 bit when any array has more than 256 entries (the original does the same for all three attributes).
